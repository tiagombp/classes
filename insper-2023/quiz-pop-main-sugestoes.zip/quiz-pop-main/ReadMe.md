
Modelo inspirado no projeto: 
https://github.com/jamesqquick/Build-A-Quiz-App-With-HTML-CSS-and-JavaScript


