function App() {
  return (
    <div>
      <h1>ALOU ALOU</h1>
    </div>
  );
}

export default App;
